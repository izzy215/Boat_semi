package ejYang.myinfo;

public class TodoBean {
	private String t_empno;
	private String t_content;
	private String t_date;
	private String t_graph;
	
	public String getT_empno() {
		return t_empno;
	}
	public void setT_empno(String t_empno) {
		this.t_empno = t_empno;
	}
	
	public String getT_content() {
		return t_content;
	}
	public void setT_content(String t_content) {
		this.t_content = t_content;
	}
	public String getT_date() {
		return t_date;
	}
	public void setT_date(String t_date) {
		this.t_date = t_date;
	}
	public String getT_graph() {
		return t_graph;
	}
	public void setT_graph(String t_graph) {
		this.t_graph = t_graph;
	}
}
