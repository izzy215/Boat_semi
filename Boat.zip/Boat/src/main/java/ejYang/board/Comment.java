package ejYang.board;

public class Comment {
	private int b_c_num;
	private String b_c_id;
	private String b_content;
	private String reg_date;
	private int b_comment_num;
	private int b_comment_re_ref;
	private int b_comment_re_lev;
	private int b_comment_re_seq;
	
	
	public int getB_c_num() {
		return b_c_num;
	}
	public void setB_c_num(int b_c_num) {
		this.b_c_num = b_c_num;
	}
	public String getB_c_id() {
		return b_c_id;
	}
	public void setB_c_id(String b_c_id) {
		this.b_c_id = b_c_id;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public int getB_comment_num() {
		return b_comment_num;
	}
	public void setB_comment_num(int b_comment_num) {
		this.b_comment_num = b_comment_num;
	}
	public int getB_comment_re_ref() {
		return b_comment_re_ref;
	}
	public void setB_comment_re_ref(int b_comment_re_ref) {
		this.b_comment_re_ref = b_comment_re_ref;
	}
	public int getB_comment_re_lev() {
		return b_comment_re_lev;
	}
	public void setB_comment_re_lev(int b_comment_re_lev) {
		this.b_comment_re_lev = b_comment_re_lev;
	}
	public int getB_comment_re_seq() {
		return b_comment_re_seq;
	}
	public void setB_comment_re_seq(int b_comment_re_seq) {
		this.b_comment_re_seq = b_comment_re_seq;
	}
}
